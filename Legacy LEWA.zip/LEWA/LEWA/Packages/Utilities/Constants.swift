//
//  Constants.swift
//  LEWA
//
//  Created by Ömer Faruk Öztürk on 22.06.2025.
//

import Foundation

enum Constants {
    static let randomImage = "https://picsum.photos/600/600"
}
