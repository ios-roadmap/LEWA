//
//  LEWATests.swift
//  LEWATests
//
//  Created by Ömer Faruk Öztürk on 22.06.2025.
//

import Testing

struct LEWATests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
