//
//  LEWAApp.swift
//  LEWA
//
//  Created by Ömer Faruk Öztürk on 22.06.2025.
//

import SwiftUI

@main
struct LEWAApp: App {
    var body: some Scene {
        WindowGroup {
            TabBarView()
                .modelContainer(for: [StarredWord.self])
        }
    }
}


