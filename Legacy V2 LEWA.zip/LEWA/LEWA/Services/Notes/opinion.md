# Ethics

## Warm-up
 1. What is ethics?
 2. Can science ever go "too far"?
 3. What are some recent developments in science and technology?
 4. Do you think all scientific discoeries should be used?
 

### Giving an opinion
- I believe this invention is etchical/unethical because...
- In my opinion, it's  dangerous because
- This could be helpful if...
- In my view, it's... because...

### Agreeing/Disagreeing
- I agree/disagree with you, especially when you said...
- I see your point, but consider this...
- That's true, but what if...

### Suggesting changes
- Maybe this invention would be better if...
- What if we only allowed it for...?

## Invention Card 1: Truth Serum Candy
A piece of candy that forces anyone who eats it to tell the turth for 1 hour. Should governments use it in trials or interviews?

**Discussion Questions**
* Is it ethical to use this in court, school, or relationships?
* Who should have access to this candy?
