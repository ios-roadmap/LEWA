precise
track record
musty
stunning
overblow
controversy
daunting
conscientious
impair
expenditure
precedent
prevalence
take into account
prone
remedy
prolong
prominent
steady
imitate
woven
skim
pile
yummy
tenacious
tenacity
run into
excessive
exhilaration
explicit
chic
chippy
arise
blender
bloom
burst into
burst out
butcher
butcher knife
flunk
flush
bystander
hesitant
mourn
spear
caregiver
intrigue
gunky
sturdy
modicum
uptight
grief
hinky
tradition
geezer
tint
mop
peep
squeeze
fidelity
whip
cope with
consult with
proofread
inmate
twist up
trip on
penitentiary
persistent
pulp
yelp
granny
perky
stand on
indispensable
extravagance
indulgence
necessity
rock paper scissors
scheme
shithead
nutjob
bluff
loony
shaky
level-headed
foreboding
nominate
extent
junkie
dig into
head -v
hook
footstool
feast
propel
extort
outrage
resurrect
senile
eerie
jump rope
choke
foolish
somber
ominous
top notch
suck up
wilderness
chopper
pulverize
tide
starry
fling
hag




